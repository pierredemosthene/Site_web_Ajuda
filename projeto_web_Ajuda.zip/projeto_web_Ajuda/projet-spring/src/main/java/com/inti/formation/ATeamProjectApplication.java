package com.inti.formation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ATeamProjectApplication {
	

	

	public static void main(String[] args) {
		SpringApplication.run(ATeamProjectApplication.class, args);
	}


}
